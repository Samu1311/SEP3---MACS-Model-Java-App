package Model;

public class QualitativeValue
{
  public enum QualitativeValues{
    BAD, MEDIUM_BAD, MEDIUM, MEDIUM_GOOD, GOOD
  }
}
