import javafx.fxml.FXML;

import java.awt.*;

public class scene1Controller
{
  @FXML  TextField bla;
  @FXML Button submit;

}
